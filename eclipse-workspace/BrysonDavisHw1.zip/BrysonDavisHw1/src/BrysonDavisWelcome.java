public class BrysonDavisWelcome {
	public static void main(String[] args) {
		System.out.println("Welcome to Java Class, and this is Bryson Davis!");
	}
}